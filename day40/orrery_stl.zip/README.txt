ORRERY FOR AN INVENTED SKY - printable parts (Day 40, thedailyfable)

Units: millimetres. Every part lies flat on z=0 in its own file; assembly.stl is the whole
mechanism at day 0 for viewing, not printing. Module 1.0 mm, 20 degree involute, 3 mm thick
wheels. Pinions under 17 teeth carry a positive profile shift and their wheels the matching
negative one, so standard centre distances hold. Bores are 0.15 mm over the arbor radius; a
real print wants its own tolerance. The base plate has no holes modelled: drill at the arbor
positions listed below. The stem is fixed; the five tubes turn on it.

Plate radius 140 mm. Day shaft at x=56.0, y=0.

Trains (crank = 1 day, clockwise seen from above):
  Ithe     true 3.371934 d   geared 3.371930 d   stages 15:31, 19:31, idler 24
  Sarrow   true 7.561208 d   geared 7.561208 d   stages 17:82, 37:58, idler 24
  Cauld    true 16.704939 d   geared 16.704939 d   stages 17:38, 17:43, 22:65
  Pellamy  true 32.744587 d   geared 32.744589 d   stages 21:32, 12:61, 22:93
  Sun      true 391.637700 d   geared 391.637701 d   stages 25:57, 13:62, 13:69, 14:95, idler 24

Arbor positions (x, y) mm:
  Ithe_A       (  48.381,   17.950)
  Ithe_I1      (  24.677,    4.009)
  Sarrow_A     (  39.105,  -11.611)
  Sarrow_I1    (   0.105,  -47.500)
  Cauld_I1     (  63.580,   26.435)
  Cauld_I2     (  33.604,   27.623)
  Pellamy_I1   (  76.739,  -16.497)
  Pellamy_I2   (  45.426,  -35.252)
  Sun_A        (  79.022,    8.379)
  Sun_I1       (  86.055,   48.264)
  Sun_I2       (  50.817,   61.090)
  Sun_I3       (  10.531,   53.473)

Gears: name, teeth, shaft, layer z0..z1, profile shift
  Ithe_g0a       z= 15  on D            layer  0  shift +0.123
  Ithe_g0b       z= 24  on Ithe_A       layer  0  shift -0.123
  Ithe_g1b       z= 31  on Ithe_I1      layer  0  shift +0.123
  Ithe_g2a       z= 19  on Ithe_I1      layer  1  shift +0.000
  Ithe_g2b       z= 31  on C            layer  1  shift -0.000
  Sarrow_g0a     z= 17  on D            layer  2  shift +0.006
  Sarrow_g0b     z= 24  on Sarrow_A     layer  2  shift -0.006
  Sarrow_g1b     z= 82  on Sarrow_I1    layer  2  shift +0.006
  Sarrow_g2a     z= 37  on Sarrow_I1    layer  3  shift +0.000
  Sarrow_g2b     z= 58  on C            layer  3  shift -0.000
  Cauld_g0a      z= 17  on D            layer  4  shift +0.006
  Cauld_g0b      z= 38  on Cauld_I1     layer  4  shift -0.006
  Cauld_g1a      z= 17  on Cauld_I1     layer  5  shift +0.006
  Cauld_g1b      z= 43  on Cauld_I2     layer  5  shift -0.006
  Cauld_g2a      z= 22  on Cauld_I2     layer  6  shift +0.000
  Cauld_g2b      z= 65  on C            layer  6  shift -0.000
  Pellamy_g0a    z= 21  on D            layer  7  shift +0.000
  Pellamy_g0b    z= 32  on Pellamy_I1   layer  7  shift -0.000
  Pellamy_g1a    z= 12  on Pellamy_I1   layer  8  shift +0.298
  Pellamy_g1b    z= 61  on Pellamy_I2   layer  8  shift -0.298
  Pellamy_g2a    z= 22  on Pellamy_I2   layer  9  shift +0.000
  Pellamy_g2b    z= 93  on C            layer  9  shift -0.000
  Sun_g0a        z= 25  on D            layer 10  shift +0.000
  Sun_g0b        z= 24  on Sun_A        layer 10  shift -0.000
  Sun_g1b        z= 57  on Sun_I1       layer 10  shift +0.000
  Sun_g2a        z= 13  on Sun_I1       layer 11  shift +0.240
  Sun_g2b        z= 62  on Sun_I2       layer 11  shift -0.240
  Sun_g3a        z= 13  on Sun_I2       layer 12  shift +0.240
  Sun_g3b        z= 69  on Sun_I3       layer 12  shift -0.240
  Sun_g4a        z= 14  on Sun_I3       layer 13  shift +0.181
  Sun_g4b        z= 95  on C            layer 13  shift -0.181
