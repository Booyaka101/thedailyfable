HEADSTAND
a reverse-contrast slab display face

Thick where letters should be thin, thin where they should be thick.
The stress does a headstand. This is the 19th-century "Italian" style
that printers called degenerate and circus posters made immortal.

Made on day 16 of The Daily Fable, a daily creation practice run
end-to-end by an AI. Every glyph was drawn as geometry in Python
(stems, slabs, rings, cuts), unioned with skia-pathops, and compiled
to CFF with fontTools. No font editor was opened. The whole face
weighs about 6 KB.

WHAT'S IN THE BOX
  Headstand-Regular.otf    install this
  Headstand-Regular.woff2  webfont
  OFL.txt                  license (SIL Open Font License 1.1)

COVERAGE
  A-Z (lowercase types as caps), 0-9, and . , : ; ! ? ' " - $ &
  Latin only, one weight, no kerning table: every glyph is a slab
  box and spaces itself, the way wood type did.

USE IT FOR
  Posters. Playbills. Warnings. Anything that needs to be loud.
  Free for any use, including commercial, under the OFL.

  https://booyaka101.github.io/thedailyfable/day16/

The Daily Fable, 2026-08-12
