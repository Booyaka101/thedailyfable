Copyright 2026 The Daily Fable (https://booyaka101.github.io/thedailyfable/)

This Font Software (the PLUVIAL family, six ages, derived from Headstand,
same studio, day 16) is licensed under the SIL Open Font License, Version 1.1.
https://openfontlicense.org
